<?php
declare(strict_types=1);

namespace FieldBlocks;

defined( 'ABSPATH' ) || exit;

use WpUtm\Attributes\InlineAsset;
use WpUtm\Interfaces\IDynamicJs;

class DynamicJs implements IDynamicJs {
}
