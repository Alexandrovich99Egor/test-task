<div class="field-blocks-classic-editor">
	<?php

	echo $block_data['editor_content'];

	?>
</div>
