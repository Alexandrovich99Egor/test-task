<?php

namespace FieldBlocks;

use WpUtm\Attributes\InlineAsset;
use WpUtm\Interfaces\IDynamicCss;

class DynamicCss implements IDynamicCss {
}
